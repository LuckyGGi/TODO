<?php
    require 'app.php';  ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>About-me</title>
		<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">   
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include('header.php');?>
    <?php  
    include('content.php'); 
    include('footer.php'); ?>
        
         
        
        
         
        