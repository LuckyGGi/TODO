<head>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>About-me</title>
		<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">   
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include('header.php');?>
<div class="container" > <h3> <p> Hello, I am junior java and full-stack web developer 
        with marketing backgroud in marketing strategy, media planing and buying.
        At the moment my focus on E-comercial and web soliutions,
        mobile apps creation, digital marketing and ads administration services
        My greatest passion is to travel. 
        Make note on my online app  and Let's talk or work on your project together! </P> </h3>
        <a href="contacts.php" class="nav-link">Contact</a></li> 
       <section>
  <div> <img class="cover" src="img/me.jpg" alt="my picture"> </section> 

</html>
<?php include'footer.php';?>
</body>
</html>